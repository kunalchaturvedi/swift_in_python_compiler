func foo() -> Int {
    var i = 1;
}

func main() -> Int {
    foo();
    return 0;
}
