# lexer assignment directory

This is a lexer for swift language. The files have ".swift" extension. This is made using "lex" from "ply" and is written in python.

## How to build

dont need to specifically use makefile. instead just use:

"python bin/lexer.py bin/test/test1.swift"  - to run test case 1
